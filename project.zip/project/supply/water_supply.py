from project.supply.supply import Supply


class WaterSupply(Supply):
    NEEDS_INCREASE = 40

    def __init__(self):
        self.needs_increase = WaterSupply.NEEDS_INCREASE
        if self.needs_increase < 0:
            raise ValueError("Needs increase cannot be less than zero.")
