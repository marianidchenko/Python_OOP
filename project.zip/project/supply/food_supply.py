from project.supply.supply import Supply


class FoodSupply(Supply):
    NEEDS_INCREASE = 20

    def __init__(self):
        self.needs_increase = FoodSupply.NEEDS_INCREASE
        if self.needs_increase < 0:
            raise ValueError("Needs increase cannot be less than zero.")
