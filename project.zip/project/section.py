from project.task import Task


class Section:
    def __init__(self, name):
        self.name = name
        self.tasks = []

    def add_task(self, task):
        if task not in self.tasks:
            self.tasks.append(task)
            return f"Task {task.details()} is added to the section"
        else:
            return f"Task is already in the section {self.name}"

    def complete_task(self, task_name):
        found = False
        for task in self.tasks:
            if task.name == task_name:
                task.completed = True
                found = True
                break
        if found:
            return f"Completed task {task_name}"
        else:
            return f"Could not find task with the name {task_name}"

    def clean_section(self):
        removed_counter = 0
        for task in self.tasks:
            if task.completed:
                self.tasks.remove(task)
                removed_counter += 1
            return f"Cleared {removed_counter} tasks."

    def view_section(self):
        result = f"Section {self.name}:" + '\n' + '\n'.join([x.details() for x in self.tasks])
        return result


